Unzip This file

Go to chrome://extensions/

Then click "Load Unpacked" and select this folder

| W.A.L.L.Y |